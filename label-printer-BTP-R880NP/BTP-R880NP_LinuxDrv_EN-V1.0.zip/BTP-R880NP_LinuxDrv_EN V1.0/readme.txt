Notes��
1.When installing printer drvier with USB interface,the printer must be printer mode on linux.

2.PrinterModeManager V1.11 is used for converting printer mode on windows OS.
  If the printer is API mode ,then convering API mode into printer mode .

3.r880npp.tar: Driver for parallel printer;
  r880nps.tar: Driver for serial printer;
  r880npu.tar: Driver for USB printer;
  When connecting Ethernet printer, use r880npp or r880npu. select"Internet Printing Protocol(ipp)", when select port. 

4.When using serial port,please type "chmod a+rwx /dev/ttyS0" to change its property

5.RTS/CTS(Hardware) is recommended  for Flow Control when Serial Port Settings.

6.Requirements: CUPS server & architecure (see www.CUPS.org)
  
   system        CUPS
  ------------------------
   FC7           1.2.10
  ------------------------
   FC8           1.3.3
  ------------------------
   FC9           1.3.7
  ------------------------
   FC10          1.3.9
  ------------------------
  Please update CUPS to 1.3.0 or higher when printer driver don't work on FC7. 

  Steps for conmpiling and installing CUPS:

  1)Download CUPS on http://www.cups.org/software.php

  2)Extract this cups-x.x.x-source.tar.gz file creating cups-x.x.x directory
  
  3)Navigate to this cups-x.x.x directory

  4)Type './configure' at the prompt to config the package

  5)Type 'make' to begin building the package

  6)Type 'make install' to install this CUPS onto your computer.

7.Please restarting CUPS after copy files to filter and model directory.

